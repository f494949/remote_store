package convert_test

import "testing"

func TestExamples(t *testing.T) {
	ExampleConvert()
	ExampleNew()
}
