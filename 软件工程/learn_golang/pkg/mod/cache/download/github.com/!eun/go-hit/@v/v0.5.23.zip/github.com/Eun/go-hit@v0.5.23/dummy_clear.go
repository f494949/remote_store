// +build generate

package hit

type IClear interface{}

func newClear(cp callPath) IClear {
	return nil
}
